#ifndef EFFECTTYPE_H
#define EFFECTTYPE_H

/*
* @todo everything
*/
enum class EffectType
{
    GROUND,
    LIFT,
    STICK,
    PARKING,
    DOOR
};

#endif
